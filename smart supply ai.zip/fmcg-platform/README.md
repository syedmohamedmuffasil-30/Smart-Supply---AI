# 🧊 Hatsun Agro — FMCG Sales Intelligence Platform

A full-stack sales intelligence platform built for Hatsun Agro Product Ltd, powering field operations for RSMs, TSMs, and Admins.

---

## 🛠️ Tech Stack

| Layer     | Technology                          |
|-----------|-------------------------------------|
| Frontend  | React (Vite) + Tailwind + Framer Motion + Recharts + React Leaflet |
| Backend   | Python FastAPI                      |
| Database  | Supabase (PostgreSQL + Auth + Realtime) |
| AI Agent  | Google Gemini (Part 3)              |

---

## 📁 Project Structure

```
fmcg-platform/
├── frontend/          ← React + Vite app
│   ├── src/
│   │   ├── components/
│   │   │   ├── GlassCard.jsx
│   │   │   ├── Navbar.jsx
│   │   │   ├── Sidebar.jsx
│   │   │   └── AIChat.jsx
│   │   ├── pages/
│   │   │   ├── Login.jsx
│   │   │   ├── Dashboard.jsx
│   │   │   ├── OutletMap.jsx
│   │   │   ├── TSMReports.jsx
│   │   │   ├── Complaints.jsx
│   │   │   ├── AIAgent.jsx
│   │   │   └── CompetitorAlerts.jsx
│   │   ├── lib/
│   │   │   └── supabase.js
│   │   └── App.jsx
└── backend/           ← FastAPI
    ├── main.py
    ├── routes/
    │   ├── users.py
    │   ├── outlets.py
    │   ├── reports.py
    │   ├── complaints.py
    │   └── alerts.py
    ├── agents/        ← AI agents (Part 3)
    ├── database/
    │   ├── supabase_client.py
    │   └── schema_and_seed.sql
    └── requirements.txt
```

---

## 🚀 Quick Start

### 1. Supabase Setup
1. Create a [Supabase](https://supabase.com) project
2. Go to **SQL Editor** and run `backend/database/schema_and_seed.sql`
3. Copy your project URL and anon key

### 2. Frontend Setup
```bash
cd frontend
cp .env.example .env
# Edit .env with your Supabase URL and anon key
npm install
npm run dev
```

### 3. Backend Setup
```bash
cd backend
cp .env.example .env
# Edit .env with your Supabase URL and service role key
pip install -r requirements.txt
python main.py
```

---

## 🎨 UI Design System

| Token      | Value         |
|------------|---------------|
| BG Gradient| `#0f0c29 → #302b63 → #24243e` |
| Primary    | `#6C63FF` (Purple)  |
| Secondary  | `#00D4FF` (Cyan)    |
| Success    | `#00FF88` (Green)   |
| Warning    | `#FFB700` (Amber)   |
| Danger     | `#FF4757` (Red)     |

All cards use `glass` morphism: `backdrop-filter: blur(20px)`, `background: rgba(255,255,255,0.08)`.

---

## 👥 Demo Credentials

| Email               | Password  | Role  |
|---------------------|-----------|-------|
| demo@hatsun.com     | demo1234  | Any   |
| arjun@hatsun.com    | (Supabase Auth) | Admin |
| priya@hatsun.com    | (Supabase Auth) | RSM   |
| rajan@hatsun.com    | (Supabase Auth) | TSM   |

---

## ✅ Parts Completed

- [x] **Part 1** — Foundation: Folder structure, Vite + React, Glassmorphism UI, Login, Supabase DB schema + seed, FastAPI routes
- [ ] **Part 2** — Feature pages: OutletMap, TSM Reports, Complaints, Competitor Alerts (Recharts + React Leaflet)
- [ ] **Part 3** — AI Agent: Google Gemini integration, intelligent query engine
