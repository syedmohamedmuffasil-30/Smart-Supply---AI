import { useState, useEffect } from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { motion } from 'framer-motion'

import Navbar from './components/Navbar'
import Sidebar from './components/Sidebar'
import AIChat from './components/AIChat'

import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import OutletMap from './pages/OutletMap'
import TSMReports from './pages/TSMReports'
import Complaints from './pages/Complaints'
import CompetitorAlerts from './pages/CompetitorAlerts'
import AIAgent from './pages/AIAgent'

import { supabase } from './lib/supabase'

function ProtectedLayout({ user, children }) {
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [aiOpen, setAiOpen] = useState(false)

  return (
    <div className="layout-root">
      <Sidebar open={sidebarOpen} user={user} />
      <div className="main-content">
        <Navbar user={user} onMenuToggle={() => setSidebarOpen(o => !o)} />
        <motion.div
          key={location.pathname}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          style={{ flex: 1 }}
        >
          {children}
        </motion.div>
      </div>

      {/* Floating AI Chat Button */}
      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setAiOpen(o => !o)}
        id="ai-chat-fab"
        style={{
          position: 'fixed', bottom: '28px', right: '28px',
          width: '58px', height: '58px', borderRadius: '18px',
          background: 'linear-gradient(135deg, #6C63FF, #00D4FF)',
          border: 'none', cursor: 'pointer', fontSize: '1.5rem',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: '0 0 30px rgba(108,99,255,0.6), 0 8px 20px rgba(0,0,0,0.4)',
          zIndex: 150,
        }}
      >🤖</motion.button>

      <AIChat open={aiOpen} onClose={() => setAiOpen(false)} />
    </div>
  )
}

export default function App() {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Check active Supabase session
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user) {
        supabase
          .from('users')
          .select('*')
          .eq('email', session.user.email)
          .single()
          .then(({ data: profile }) => {
            setUser({ ...session.user, ...profile })
          })
          .catch(() => setUser(session.user))
      }
      setLoading(false)
    })

    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      if (!session) setUser(null)
    })
    return () => listener.subscription.unsubscribe()
  }, [])

  if (loading) {
    return (
      <div style={{
        minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center',
        background: 'linear-gradient(135deg, #0f0c29, #302b63, #24243e)',
        flexDirection: 'column', gap: '20px',
      }}>
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1.5, repeat: Infinity, ease: 'linear' }}
          style={{
            width: '60px', height: '60px', borderRadius: '50%',
            border: '3px solid transparent',
            borderTopColor: '#6C63FF', borderRightColor: '#00D4FF',
          }}
        />
        <p style={{ color: 'rgba(255,255,255,0.4)', fontSize: '0.88rem' }}>Loading Hatsun Agro Platform...</p>
      </div>
    )
  }

  return (
    <BrowserRouter>
      <Routes>
        {/* Public route */}
        <Route
          path="/"
          element={user ? <Navigate to="/dashboard" replace /> : <Login onLogin={setUser} />}
        />

        {/* Protected routes */}
        <Route
          path="/dashboard"
          element={user
            ? <ProtectedLayout user={user}><Dashboard user={user} /></ProtectedLayout>
            : <Navigate to="/" replace />}
        />
        <Route
          path="/map"
          element={user
            ? <ProtectedLayout user={user}><OutletMap user={user} /></ProtectedLayout>
            : <Navigate to="/" replace />}
        />
        <Route
          path="/reports"
          element={user
            ? <ProtectedLayout user={user}><TSMReports user={user} /></ProtectedLayout>
            : <Navigate to="/" replace />}
        />
        <Route
          path="/complaints"
          element={user
            ? <ProtectedLayout user={user}><Complaints user={user} /></ProtectedLayout>
            : <Navigate to="/" replace />}
        />
        <Route
          path="/alerts"
          element={user
            ? <ProtectedLayout user={user}><CompetitorAlerts user={user} /></ProtectedLayout>
            : <Navigate to="/" replace />}
        />
        <Route
          path="/ai"
          element={user
            ? <ProtectedLayout user={user}><AIAgent user={user} /></ProtectedLayout>
            : <Navigate to="/" replace />}
        />

        {/* Catch-all */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  )
}
