import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import GlassCard from '../components/GlassCard'

const ROLES = ['TSM', 'RSM', 'Admin']

const roleInfo = {
  TSM: { icon: '🚗', desc: 'Territory Sales Manager', color: '#00FF88' },
  RSM: { icon: '📍', desc: 'Regional Sales Manager', color: '#00D4FF' },
  Admin: { icon: '🛡️', desc: 'Platform Administrator', color: '#6C63FF' },
}

export default function Login({ onLogin }) {
  const navigate = useNavigate()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [role, setRole] = useState('TSM')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [showPass, setShowPass] = useState(false)

  const handleLogin = async (e) => {
    e.preventDefault()
    setError('')
    if (!email || !password) { setError('Please enter email and password.'); return }
    setLoading(true)

    try {
      const { data, error: authError } = await supabase.auth.signInWithPassword({ email, password })
      if (authError) throw authError

      // Fetch user profile from our users table
      const { data: profile } = await supabase
        .from('users')
        .select('*')
        .eq('email', email)
        .single()

      const user = { ...data.user, ...profile, role: profile?.role || role }
      onLogin(user)
      navigate('/dashboard')
    } catch (err) {
      // Demo fallback – allow bypass with demo credentials
      if (email === 'demo@hatsun.com' && password === 'demo1234') {
        const demoUser = { name: 'Demo User', email, role, region: 'Chennai Zone' }
        onLogin(demoUser)
        navigate('/dashboard')
      } else {
        setError(err.message || 'Login failed. Try demo@hatsun.com / demo1234')
      }
    } finally {
      setLoading(false)
    }
  }

  const selectedRole = roleInfo[role]

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'linear-gradient(135deg, #0f0c29 0%, #302b63 50%, #24243e 100%)',
      padding: '20px',
      position: 'relative',
      overflow: 'hidden',
    }}>
      {/* Animated background orbs */}
      <motion.div
        animate={{ x: [0, 40, 0], y: [0, -30, 0] }}
        transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
        style={{
          position: 'absolute', top: '10%', left: '10%',
          width: '400px', height: '400px', borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(108,99,255,0.15), transparent 70%)',
          filter: 'blur(40px)', pointerEvents: 'none',
        }}
      />
      <motion.div
        animate={{ x: [0, -30, 0], y: [0, 40, 0] }}
        transition={{ duration: 10, repeat: Infinity, ease: 'easeInOut' }}
        style={{
          position: 'absolute', bottom: '10%', right: '10%',
          width: '350px', height: '350px', borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(0,212,255,0.12), transparent 70%)',
          filter: 'blur(40px)', pointerEvents: 'none',
        }}
      />

      <div style={{ width: '100%', maxWidth: '440px', position: 'relative', zIndex: 1 }}>
        {/* Logo / Brand */}
        <motion.div
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          style={{ textAlign: 'center', marginBottom: '32px' }}
        >
          <motion.div
            animate={{ rotate: [0, 360] }}
            transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
            style={{
              width: '72px', height: '72px', borderRadius: '20px',
              background: 'linear-gradient(135deg, #6C63FF, #00D4FF)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              margin: '0 auto 16px',
              boxShadow: '0 0 40px rgba(108,99,255,0.5)',
              fontSize: '2rem', position: 'relative',
            }}
          >
            🧊
          </motion.div>
          <h1 style={{
            fontSize: '1.8rem', fontWeight: 800, lineHeight: 1.2,
            background: 'linear-gradient(90deg, #6C63FF, #00D4FF)',
            WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
          }}>
            Hatsun Agro
          </h1>
          <p style={{ color: 'rgba(255,255,255,0.5)', fontSize: '0.88rem', marginTop: '4px' }}>
            FMCG Sales Intelligence Platform
          </p>
        </motion.div>

        {/* Login Card */}
        <GlassCard glow="purple" delay={0.1}>
          <h2 style={{ fontWeight: 700, fontSize: '1.25rem', marginBottom: '6px' }}>Welcome back 👋</h2>
          <p style={{ color: 'rgba(255,255,255,0.45)', fontSize: '0.83rem', marginBottom: '28px' }}>
            Sign in to access your sales dashboard
          </p>

          {/* Role Selector */}
          <div style={{ marginBottom: '24px' }}>
            <label style={{ fontSize: '0.78rem', color: 'rgba(255,255,255,0.5)', fontWeight: 500, display: 'block', marginBottom: '10px' }}>
              SELECT YOUR ROLE
            </label>
            <div style={{ display: 'flex', gap: '8px' }}>
              {ROLES.map(r => (
                <motion.button
                  key={r}
                  id={`role-${r.toLowerCase()}`}
                  whileHover={{ scale: 1.04 }}
                  whileTap={{ scale: 0.97 }}
                  onClick={() => setRole(r)}
                  style={{
                    flex: 1,
                    padding: '10px 8px',
                    borderRadius: '12px',
                    border: role === r
                      ? `1px solid ${roleInfo[r].color}`
                      : '1px solid rgba(255,255,255,0.12)',
                    background: role === r
                      ? `${roleInfo[r].color}22`
                      : 'rgba(255,255,255,0.04)',
                    color: role === r ? roleInfo[r].color : 'rgba(255,255,255,0.5)',
                    cursor: 'pointer',
                    fontFamily: 'Inter, sans-serif',
                    fontSize: '0.8rem',
                    fontWeight: 600,
                    transition: 'all 0.25s ease',
                    boxShadow: role === r ? `0 0 12px ${roleInfo[r].color}33` : 'none',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    gap: '4px',
                  }}
                >
                  <span style={{ fontSize: '1.1rem' }}>{roleInfo[r].icon}</span>
                  {r}
                </motion.button>
              ))}
            </div>
            <AnimatePresence mode="wait">
              <motion.p
                key={role}
                initial={{ opacity: 0, y: -6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 6 }}
                style={{
                  fontSize: '0.73rem', color: selectedRole.color,
                  marginTop: '8px', textAlign: 'center',
                }}
              >
                {selectedRole.icon} {selectedRole.desc}
              </motion.p>
            </AnimatePresence>
          </div>

          {/* Form */}
          <form onSubmit={handleLogin} style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            {/* Email */}
            <div>
              <label htmlFor="login-email" style={{ fontSize: '0.78rem', color: 'rgba(255,255,255,0.5)', fontWeight: 500, display: 'block', marginBottom: '8px' }}>
                EMAIL ADDRESS
              </label>
              <div style={{ position: 'relative' }}>
                <span style={{ position: 'absolute', left: '14px', top: '50%', transform: 'translateY(-50%)', fontSize: '1rem', pointerEvents: 'none' }}>✉️</span>
                <input
                  id="login-email"
                  type="email"
                  className="glass-input"
                  placeholder="you@hatsun.com"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  required
                  style={{ paddingLeft: '42px' }}
                  autoComplete="email"
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label htmlFor="login-password" style={{ fontSize: '0.78rem', color: 'rgba(255,255,255,0.5)', fontWeight: 500, display: 'block', marginBottom: '8px' }}>
                PASSWORD
              </label>
              <div style={{ position: 'relative' }}>
                <span style={{ position: 'absolute', left: '14px', top: '50%', transform: 'translateY(-50%)', fontSize: '1rem', pointerEvents: 'none' }}>🔒</span>
                <input
                  id="login-password"
                  type={showPass ? 'text' : 'password'}
                  className="glass-input"
                  placeholder="••••••••"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  required
                  style={{ paddingLeft: '42px', paddingRight: '44px' }}
                  autoComplete="current-password"
                />
                <button
                  type="button"
                  onClick={() => setShowPass(!showPass)}
                  style={{
                    position: 'absolute', right: '12px', top: '50%', transform: 'translateY(-50%)',
                    background: 'none', border: 'none', cursor: 'pointer', color: 'rgba(255,255,255,0.5)',
                    fontSize: '0.9rem',
                  }}
                >{showPass ? '🙈' : '👁️'}</button>
              </div>
            </div>

            {/* Error */}
            <AnimatePresence>
              {error && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  style={{
                    background: 'rgba(255,71,87,0.12)',
                    border: '1px solid rgba(255,71,87,0.3)',
                    borderRadius: '10px', padding: '10px 14px',
                    color: '#FF4757', fontSize: '0.82rem',
                  }}
                >
                  ⚠️ {error}
                </motion.div>
              )}
            </AnimatePresence>

            {/* Submit */}
            <motion.button
              type="submit"
              id="login-submit"
              className="btn-glow"
              disabled={loading}
              whileHover={{ scale: loading ? 1 : 1.02 }}
              whileTap={{ scale: loading ? 1 : 0.98 }}
              style={{ width: '100%', marginTop: '4px', opacity: loading ? 0.75 : 1 }}
            >
              <span>
                {loading ? (
                  <span style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px' }}>
                    <motion.span
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                      style={{ display: 'inline-block', fontSize: '1rem' }}
                    >⟳</motion.span>
                    Signing in...
                  </span>
                ) : `Sign In as ${role} →`}
              </span>
            </motion.button>
          </form>

          {/* Demo hint */}
          <div style={{
            marginTop: '20px',
            padding: '12px 16px',
            background: 'rgba(108,99,255,0.1)',
            border: '1px solid rgba(108,99,255,0.25)',
            borderRadius: '12px',
          }}>
            <p style={{ fontSize: '0.75rem', color: 'rgba(255,255,255,0.5)', textAlign: 'center' }}>
              🎭 <strong style={{ color: 'rgba(255,255,255,0.7)' }}>Demo credentials:</strong>{' '}
              <code style={{ color: '#00D4FF' }}>demo@hatsun.com</code> /{' '}
              <code style={{ color: '#00FF88' }}>demo1234</code>
            </p>
          </div>
        </GlassCard>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          style={{ textAlign: 'center', marginTop: '20px', fontSize: '0.72rem', color: 'rgba(255,255,255,0.25)' }}
        >
          © 2025 Hatsun Agro Product Ltd · All rights reserved
        </motion.p>
      </div>
    </div>
  )
}
