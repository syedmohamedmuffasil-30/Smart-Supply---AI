import GlassCard from '../components/GlassCard'

export default function TSMReports() {
  return (
    <div style={{ padding: '28px' }}>
      <h1 style={{ fontSize: '1.6rem', fontWeight: 800, marginBottom: '8px' }}>📋 <span className="text-gradient-purple">TSM Reports</span></h1>
      <p style={{ color: 'rgba(255,255,255,0.45)', fontSize: '0.88rem', marginBottom: '24px' }}>Field activity reports from Territory Sales Managers</p>
      <GlassCard>
        <div style={{ height: '400px', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: '12px' }}>
          <span style={{ fontSize: '3rem' }}>📋</span>
          <p style={{ color: 'rgba(255,255,255,0.5)' }}>TSM report submission & review loads in Part 2</p>
        </div>
      </GlassCard>
    </div>
  )
}
