import GlassCard from '../components/GlassCard'

export default function AIAgent() {
  return (
    <div style={{ padding: '28px' }}>
      <h1 style={{ fontSize: '1.6rem', fontWeight: 800, marginBottom: '8px' }}>🤖 <span className="text-gradient-purple">AI Agent</span></h1>
      <p style={{ color: 'rgba(255,255,255,0.45)', fontSize: '0.88rem', marginBottom: '24px' }}>Your intelligent FMCG sales co-pilot</p>
      <GlassCard>
        <div style={{ height: '400px', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: '12px' }}>
          <span style={{ fontSize: '3rem' }}>🤖</span>
          <p style={{ color: 'rgba(255,255,255,0.5)' }}>Full AI agent interface loads in Part 3</p>
          <p style={{ fontSize: '0.78rem', color: 'rgba(255,255,255,0.3)' }}>Google Gemini + FastAPI Agent</p>
        </div>
      </GlassCard>
    </div>
  )
}
