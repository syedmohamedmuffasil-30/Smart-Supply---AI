import GlassCard from '../components/GlassCard'

export default function OutletMap() {
  return (
    <div style={{ padding: '28px' }}>
      <h1 style={{ fontSize: '1.6rem', fontWeight: 800, marginBottom: '8px' }}>🗺️ <span className="text-gradient-purple">Outlet Map</span></h1>
      <p style={{ color: 'rgba(255,255,255,0.45)', fontSize: '0.88rem', marginBottom: '24px' }}>Real-time outlet locations across your territory</p>
      <GlassCard>
        <div style={{ height: '500px', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: '12px' }}>
          <span style={{ fontSize: '3rem' }}>🗺️</span>
          <p style={{ color: 'rgba(255,255,255,0.5)' }}>Interactive map loads in Part 2</p>
          <p style={{ fontSize: '0.78rem', color: 'rgba(255,255,255,0.3)' }}>React Leaflet + Supabase outlets table</p>
        </div>
      </GlassCard>
    </div>
  )
}
