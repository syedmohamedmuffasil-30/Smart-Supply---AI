import GlassCard from '../components/GlassCard'
import { motion } from 'framer-motion'

const stats = [
  { label: 'Active Outlets', value: '247', icon: '🏪', color: '#6C63FF', delta: '+12 this week' },
  { label: 'Orders Today',   value: '₹4.2L', icon: '📦', color: '#00D4FF', delta: '+18% vs yesterday' },
  { label: 'Stockout Alerts',value: '3',    icon: '⚠️', color: '#FFB700', delta: '2 resolved today' },
  { label: 'Open Complaints',value: '7',    icon: '🚨', color: '#FF4757', delta: '3 critical' },
]

export default function Dashboard({ user }) {
  return (
    <div style={{ padding: '28px', display: 'flex', flexDirection: 'column', gap: '24px' }}>
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: -12 }} animate={{ opacity: 1, y: 0 }}>
        <h1 style={{ fontSize: '1.6rem', fontWeight: 800 }}>
          Good day, <span className="text-gradient-purple">{user?.name || 'Agent'} 👋</span>
        </h1>
        <p style={{ color: 'rgba(255,255,255,0.45)', fontSize: '0.88rem', marginTop: '4px' }}>
          {new Date().toLocaleDateString('en-IN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
        </p>
      </motion.div>

      {/* KPI Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '16px' }}>
        {stats.map((s, i) => (
          <GlassCard key={s.label} delay={i * 0.08} hover>
            <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
              <div>
                <p style={{ fontSize: '0.75rem', color: 'rgba(255,255,255,0.45)', fontWeight: 500, marginBottom: '6px' }}>{s.label}</p>
                <p style={{ fontSize: '2rem', fontWeight: 800, color: s.color, lineHeight: 1 }}>{s.value}</p>
                <p style={{ fontSize: '0.72rem', color: 'rgba(255,255,255,0.35)', marginTop: '6px' }}>{s.delta}</p>
              </div>
              <div style={{
                width: '44px', height: '44px', borderRadius: '12px',
                background: `${s.color}18`, border: `1px solid ${s.color}33`,
                display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.4rem',
              }}>{s.icon}</div>
            </div>
          </GlassCard>
        ))}
      </div>

      {/* Placeholder chart area */}
      <GlassCard delay={0.3}>
        <p style={{ fontWeight: 700, marginBottom: '12px' }}>📈 Sales Trend — Last 7 Days</p>
        <div className="skeleton" style={{ height: '180px', borderRadius: '12px' }} />
      </GlassCard>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
        <GlassCard delay={0.4}>
          <p style={{ fontWeight: 700, marginBottom: '12px' }}>🗺️ Top Performing Districts</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {['Chennai', 'Coimbatore', 'Madurai', 'Salem'].map((d, i) => (
              <div key={d} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: '0.83rem', color: 'rgba(255,255,255,0.7)' }}>{d}</span>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <div style={{ width: `${90 - i * 16}px`, height: '6px', borderRadius: '3px', background: 'linear-gradient(90deg, #6C63FF, #00D4FF)' }} />
                  <span style={{ fontSize: '0.75rem', color: '#00FF88', fontWeight: 600 }}>{90 - i * 16}%</span>
                </div>
              </div>
            ))}
          </div>
        </GlassCard>
        <GlassCard delay={0.45}>
          <p style={{ fontWeight: 700, marginBottom: '12px' }}>⚡ Recent Alerts</p>
          {[
            { t: 'Stockout — Velachery', c: '#FFB700', time: '2m ago' },
            { t: 'Complaint — T.Nagar', c: '#FF4757', time: '18m ago' },
            { t: 'Competitor — Tambaram', c: '#FF4757', time: '1h ago' },
          ].map((a, i) => (
            <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <span style={{ width: '8px', height: '8px', borderRadius: '50%', background: a.c, boxShadow: `0 0 6px ${a.c}`, display: 'inline-block' }} />
                <span style={{ fontSize: '0.8rem', color: 'rgba(255,255,255,0.75)' }}>{a.t}</span>
              </div>
              <span style={{ fontSize: '0.7rem', color: 'rgba(255,255,255,0.35)' }}>{a.time}</span>
            </div>
          ))}
        </GlassCard>
      </div>
    </div>
  )
}
