import { motion, AnimatePresence } from 'framer-motion'
import { useLocation, useNavigate } from 'react-router-dom'

const navItems = [
  { id: 'sidebar-dashboard',        icon: '📊', label: 'Dashboard',         path: '/dashboard'  },
  { id: 'sidebar-outlet-map',       icon: '🗺️', label: 'Outlet Map',        path: '/map'        },
  { id: 'sidebar-tsm-reports',      icon: '📋', label: 'TSM Reports',       path: '/reports'    },
  { id: 'sidebar-complaints',       icon: '🚨', label: 'Complaints',         path: '/complaints' },
  { id: 'sidebar-competitor-alerts',icon: '⚡', label: 'Competitor Alerts',  path: '/alerts'     },
  { id: 'sidebar-ai-agent',         icon: '🤖', label: 'AI Agent',           path: '/ai'         },
]

const roleColors = {
  Admin: { bg: 'rgba(108,99,255,0.2)', color: '#6C63FF', border: 'rgba(108,99,255,0.4)' },
  RSM:   { bg: 'rgba(0,212,255,0.2)',  color: '#00D4FF', border: 'rgba(0,212,255,0.4)'  },
  TSM:   { bg: 'rgba(0,255,136,0.2)',  color: '#00FF88', border: 'rgba(0,255,136,0.4)'  },
}

export default function Sidebar({ open, user }) {
  const location = useLocation()
  const navigate = useNavigate()
  const role = user?.role || 'TSM'
  const rc = roleColors[role] || roleColors.TSM

  return (
    <AnimatePresence>
      {open && (
        <motion.aside
          key="sidebar"
          initial={{ x: -260, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          exit={{ x: -260, opacity: 0 }}
          transition={{ type: 'spring', stiffness: 300, damping: 30 }}
          className="sidebar glass"
          style={{
            borderRadius: '0 20px 20px 0',
            borderLeft: 'none',
            borderTop: 'none',
            borderBottom: 'none',
            display: 'flex',
            flexDirection: 'column',
            padding: '24px 16px',
            gap: '8px',
            zIndex: 90,
          }}
        >
          {/* User info block */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.15 }}
            style={{
              background: rc.bg,
              border: `1px solid ${rc.border}`,
              borderRadius: '14px',
              padding: '16px',
              marginBottom: '16px',
              display: 'flex',
              alignItems: 'center',
              gap: '12px',
            }}
          >
            <div style={{
              width: '44px', height: '44px', borderRadius: '12px',
              background: `linear-gradient(135deg, ${rc.color}, #24243e)`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontWeight: 800, fontSize: '1.1rem', color: '#fff',
              flexShrink: 0,
            }}>
              {user?.name?.charAt(0).toUpperCase() || 'U'}
            </div>
            <div style={{ overflow: 'hidden' }}>
              <p style={{ fontWeight: 700, fontSize: '0.88rem', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                {user?.name || 'Field Agent'}
              </p>
              <p style={{ fontSize: '0.72rem', color: 'rgba(255,255,255,0.5)', marginBottom: '4px' }}>
                {user?.region || 'Chennai Region'}
              </p>
              <span style={{
                fontSize: '0.7rem', padding: '2px 10px', borderRadius: '99px',
                background: rc.bg, color: rc.color,
                border: `1px solid ${rc.border}`, fontWeight: 700,
              }}>{role}</span>
            </div>
          </motion.div>

          {/* Nav Links */}
          <nav style={{ display: 'flex', flexDirection: 'column', gap: '4px', flex: 1 }}>
            <p style={{ fontSize: '0.68rem', color: 'rgba(255,255,255,0.35)', fontWeight: 600, letterSpacing: '1px', padding: '0 8px', marginBottom: '8px' }}>
              NAVIGATION
            </p>
            {navItems.map((item, i) => {
              const isActive = location.pathname === item.path
              return (
                <motion.button
                  key={item.id}
                  id={item.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.08 * i }}
                  whileHover={{ x: 4 }}
                  whileTap={{ scale: 0.97 }}
                  onClick={() => navigate(item.path)}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                    width: '100%',
                    padding: '11px 14px',
                    borderRadius: '12px',
                    border: isActive ? '1px solid rgba(108,99,255,0.5)' : '1px solid transparent',
                    background: isActive
                      ? 'linear-gradient(135deg, rgba(108,99,255,0.25), rgba(0,212,255,0.1))'
                      : 'transparent',
                    color: isActive ? '#6C63FF' : 'rgba(255,255,255,0.7)',
                    cursor: 'pointer',
                    fontFamily: 'Inter, sans-serif',
                    fontSize: '0.88rem',
                    fontWeight: isActive ? 600 : 400,
                    textAlign: 'left',
                    transition: 'all 0.2s ease',
                    boxShadow: isActive ? '0 0 16px rgba(108,99,255,0.2)' : 'none',
                  }}
                >
                  <span style={{ fontSize: '1.1rem', flexShrink: 0 }}>{item.icon}</span>
                  {item.label}
                  {isActive && (
                    <motion.div
                      layoutId="active-pill"
                      style={{
                        marginLeft: 'auto', width: '6px', height: '6px',
                        borderRadius: '50%', background: '#6C63FF',
                        boxShadow: '0 0 8px #6C63FF',
                      }}
                    />
                  )}
                </motion.button>
              )
            })}
          </nav>

          {/* Footer */}
          <div style={{
            borderTop: '1px solid rgba(255,255,255,0.1)',
            paddingTop: '16px',
            marginTop: '8px',
          }}>
            <p style={{ fontSize: '0.68rem', color: 'rgba(255,255,255,0.3)', textAlign: 'center' }}>
              © 2025 Hatsun Agro Product Ltd
            </p>
            <p style={{ fontSize: '0.65rem', color: 'rgba(108,99,255,0.6)', textAlign: 'center', marginTop: '2px' }}>
              v1.0.0 — Sales Intelligence
            </p>
          </div>
        </motion.aside>
      )}
    </AnimatePresence>
  )
}
