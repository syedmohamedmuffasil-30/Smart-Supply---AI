import { motion } from 'framer-motion'

/**
 * GlassCard — Reusable glassmorphism card component.
 *
 * Props:
 *  children   – card body content
 *  className  – extra Tailwind / CSS classes
 *  hover      – boolean, enable lift + neon glow on hover (default true)
 *  glow       – 'purple' | 'cyan' | 'green' | null
 *  padding    – inline style padding override (default '24px')
 *  onClick    – optional click handler
 *  animate    – boolean, fade-in on mount (default true)
 *  delay      – framer-motion delay in seconds (default 0)
 */
export default function GlassCard({
  children,
  className = '',
  hover = true,
  glow = null,
  padding = '24px',
  onClick,
  animate = true,
  delay = 0,
}) {
  const glowMap = {
    purple: '0 0 24px rgba(108,99,255,0.45)',
    cyan:   '0 0 24px rgba(0,212,255,0.45)',
    green:  '0 0 24px rgba(0,255,136,0.45)',
  }

  return (
    <motion.div
      initial={animate ? { opacity: 0, y: 16 } : false}
      animate={animate ? { opacity: 1, y: 0 } : false}
      transition={{ duration: 0.45, delay, ease: 'easeOut' }}
      whileHover={hover ? { y: -4 } : {}}
      onClick={onClick}
      className={`glass ${hover ? 'glass-hover' : ''} ${className}`}
      style={{
        padding,
        cursor: onClick ? 'pointer' : 'default',
        boxShadow: glow
          ? `0 8px 32px rgba(0,0,0,0.3), ${glowMap[glow]}`
          : '0 8px 32px rgba(0,0,0,0.3)',
      }}
    >
      {children}
    </motion.div>
  )
}
