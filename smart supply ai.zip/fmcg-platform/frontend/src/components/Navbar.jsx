import { motion } from 'framer-motion'
import { useState } from 'react'
import { supabase } from '../lib/supabase'

const roleColors = {
  Admin: '#6C63FF',
  RSM:   '#00D4FF',
  TSM:   '#00FF88',
}

export default function Navbar({ user, onMenuToggle }) {
  const [notifOpen, setNotifOpen] = useState(false)

  const handleLogout = async () => {
    await supabase.auth.signOut()
    window.location.href = '/'
  }

  return (
    <motion.header
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="glass"
      style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '14px 24px',
        borderRadius: '0',
        borderBottom: '1px solid rgba(255,255,255,0.1)',
        borderTop: 'none',
        borderLeft: 'none',
        borderRight: 'none',
        backdropFilter: 'blur(20px)',
        position: 'sticky',
        top: 0,
        zIndex: 100,
      }}
    >
      {/* Left: Hamburger + Brand */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.95 }}
          onClick={onMenuToggle}
          style={{
            background: 'rgba(255,255,255,0.08)',
            border: '1px solid rgba(255,255,255,0.15)',
            borderRadius: '10px',
            cursor: 'pointer',
            padding: '8px 10px',
            color: '#fff',
            display: 'flex',
            flexDirection: 'column',
            gap: '4px',
          }}
          aria-label="Toggle sidebar"
        >
          <span style={{ display: 'block', width: '18px', height: '2px', background: '#fff', borderRadius: '2px' }} />
          <span style={{ display: 'block', width: '14px', height: '2px', background: '#6C63FF', borderRadius: '2px' }} />
          <span style={{ display: 'block', width: '18px', height: '2px', background: '#fff', borderRadius: '2px' }} />
        </motion.button>

        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <div style={{
            width: '36px', height: '36px', borderRadius: '10px',
            background: 'linear-gradient(135deg, #6C63FF, #00D4FF)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontWeight: '800', fontSize: '1rem', color: '#fff',
            boxShadow: '0 0 16px rgba(108,99,255,0.5)',
          }}>H</div>
          <div>
            <p style={{ fontWeight: 700, fontSize: '0.95rem', lineHeight: 1.2 }}>Hatsun Agro</p>
            <p style={{ fontSize: '0.72rem', color: 'rgba(255,255,255,0.5)', lineHeight: 1.2 }}>Sales Intelligence Platform</p>
          </div>
        </div>
      </div>

      {/* Right: Notifications + User */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
        {/* Live pulse */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
          <span style={{
            width: '8px', height: '8px', borderRadius: '50%',
            background: '#00FF88',
            boxShadow: '0 0 8px #00FF88',
            animation: 'pulse 2s infinite',
          }} />
          <span style={{ fontSize: '0.75rem', color: '#00FF88', fontWeight: 500 }}>Live</span>
        </div>

        {/* Notification bell */}
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setNotifOpen(!notifOpen)}
          id="navbar-notifications"
          style={{
            background: 'rgba(255,255,255,0.08)',
            border: '1px solid rgba(255,255,255,0.15)',
            borderRadius: '10px',
            cursor: 'pointer',
            padding: '8px 10px',
            color: '#fff',
            position: 'relative',
            fontSize: '1.1rem',
          }}
          aria-label="Notifications"
        >
          🔔
          <span style={{
            position: 'absolute', top: '4px', right: '4px',
            width: '8px', height: '8px', background: '#FF4757',
            borderRadius: '50%', boxShadow: '0 0 6px #FF4757',
          }} />
        </motion.button>

        {/* User card */}
        {user && (
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <div style={{
              width: '36px', height: '36px', borderRadius: '50%',
              background: `linear-gradient(135deg, ${roleColors[user.role] || '#6C63FF'}, #24243e)`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontWeight: 700, fontSize: '0.9rem', color: '#fff',
              border: '2px solid rgba(255,255,255,0.2)',
            }}>
              {user.name?.charAt(0).toUpperCase() || 'U'}
            </div>
            <div style={{ display: 'none' }} className="sm:block">
              <p style={{ fontSize: '0.82rem', fontWeight: 600, lineHeight: 1.2 }}>{user.name || 'User'}</p>
              <span style={{
                fontSize: '0.7rem', padding: '2px 8px', borderRadius: '99px',
                background: `${roleColors[user.role] || '#6C63FF'}22`,
                color: roleColors[user.role] || '#6C63FF',
                border: `1px solid ${roleColors[user.role] || '#6C63FF'}44`,
                fontWeight: 600,
              }}>{user.role || 'TSM'}</span>
            </div>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={handleLogout}
              id="navbar-logout"
              style={{
                background: 'rgba(255,71,87,0.15)',
                border: '1px solid rgba(255,71,87,0.3)',
                borderRadius: '8px', cursor: 'pointer',
                padding: '6px 12px', color: '#FF4757',
                fontSize: '0.78rem', fontWeight: 600,
                fontFamily: 'Inter, sans-serif',
              }}
            >Logout</motion.button>
          </div>
        )}
      </div>

      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.4; }
        }
      `}</style>
    </motion.header>
  )
}
