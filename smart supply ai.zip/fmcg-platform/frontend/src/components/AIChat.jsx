import { useState, useRef, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import GlassCard from './GlassCard'

const QUICK_PROMPTS = [
  '📊 Show today\'s sales summary',
  '🚨 Which outlets have stockouts?',
  '⚡ Latest competitor threats',
  '📋 Pending TSM reports',
]

export default function AIChat({ open, onClose }) {
  const [messages, setMessages] = useState([
    {
      role: 'assistant',
      text: '👋 Hi! I\'m your FMCG Sales AI. Ask me about outlet performance, stockouts, competitor activity, or TSM reports.',
    },
  ])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const bottomRef = useRef(null)

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const sendMessage = async (text) => {
    const userText = text || input.trim()
    if (!userText) return
    setInput('')
    setMessages(prev => [...prev, { role: 'user', text: userText }])
    setLoading(true)

    // Simulate AI response (replace with actual FastAPI call in Part 3)
    await new Promise(r => setTimeout(r, 1200))
    const reply = generateMockReply(userText)
    setMessages(prev => [...prev, { role: 'assistant', text: reply }])
    setLoading(false)
  }

  const generateMockReply = (q) => {
    const low = q.toLowerCase()
    if (low.includes('stockout') || low.includes('stock')) return '⚠️ **3 outlets** currently have stockouts: Velachery (Arun Ice Cream), T.Nagar (Ibaco), and Adyar (Hatsun Curd 500g). Recommend dispatching from Chennai Central hub.'
    if (low.includes('competitor') || low.includes('threat')) return '⚡ **2 high-threat alerts**: Amul launched a ₹5 price cut on butter in T.Nagar cluster. Dodla Dairy running a buy-2-get-1 promo in Tambaram. Action required within 24h.'
    if (low.includes('sales') || low.includes('summary')) return '📊 Today\'s snapshot: **₹4.2L** revenue across **47 outlets**, up 12% vs last week. Top SKU: Hatsun Curd 1L. Laggard: Frozen desserts (-8%).'
    if (low.includes('report') || low.includes('tsm')) return '📋 **2 TSM reports** pending today: Rajan (South Zone) and Priya (East Zone) haven\'t submitted. Deadline: 6:00 PM.'
    return '🤖 I\'m querying the FMCG intelligence database... For customized insights, connect the AI agent to your FastAPI backend (Part 3).'
  }

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0, scale: 0.92, x: 40 }}
          animate={{ opacity: 1, scale: 1, x: 0 }}
          exit={{ opacity: 0, scale: 0.92, x: 40 }}
          transition={{ type: 'spring', stiffness: 300, damping: 28 }}
          style={{
            position: 'fixed', bottom: '90px', right: '24px',
            width: '360px', zIndex: 200,
          }}
        >
          <GlassCard padding="0" glow="purple" animate={false}>
            {/* Header */}
            <div style={{
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              padding: '16px 20px',
              borderBottom: '1px solid rgba(255,255,255,0.1)',
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <div style={{
                  width: '34px', height: '34px', borderRadius: '10px',
                  background: 'linear-gradient(135deg, #6C63FF, #00D4FF)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: '1.1rem',
                }}>🤖</div>
                <div>
                  <p style={{ fontWeight: 700, fontSize: '0.9rem' }}>FMCG AI Agent</p>
                  <p style={{ fontSize: '0.7rem', color: '#00FF88' }}>● Online</p>
                </div>
              </div>
              <motion.button
                whileHover={{ scale: 1.1, rotate: 90 }}
                whileTap={{ scale: 0.9 }}
                onClick={onClose}
                id="aichat-close"
                style={{
                  background: 'rgba(255,71,87,0.15)', border: '1px solid rgba(255,71,87,0.3)',
                  borderRadius: '8px', color: '#FF4757', cursor: 'pointer',
                  padding: '4px 10px', fontSize: '1rem', fontFamily: 'Inter',
                }}
              >✕</motion.button>
            </div>

            {/* Messages */}
            <div style={{ height: '280px', overflowY: 'auto', padding: '16px', display: 'flex', flexDirection: 'column', gap: '12px' }}>
              {messages.map((msg, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                  style={{
                    display: 'flex',
                    justifyContent: msg.role === 'user' ? 'flex-end' : 'flex-start',
                  }}
                >
                  <div style={{
                    maxWidth: '85%',
                    padding: '10px 14px',
                    borderRadius: msg.role === 'user' ? '14px 14px 4px 14px' : '14px 14px 14px 4px',
                    background: msg.role === 'user'
                      ? 'linear-gradient(135deg, #6C63FF, #00D4FF)'
                      : 'rgba(255,255,255,0.08)',
                    border: msg.role === 'assistant' ? '1px solid rgba(255,255,255,0.12)' : 'none',
                    fontSize: '0.82rem',
                    lineHeight: 1.5,
                    color: '#fff',
                  }}>
                    {msg.text}
                  </div>
                </motion.div>
              ))}
              {loading && (
                <div style={{ display: 'flex', gap: '4px', padding: '8px 14px' }}>
                  {[0, 1, 2].map(i => (
                    <motion.span
                      key={i}
                      animate={{ y: [0, -6, 0] }}
                      transition={{ duration: 0.6, repeat: Infinity, delay: i * 0.15 }}
                      style={{ width: '6px', height: '6px', borderRadius: '50%', background: '#6C63FF', display: 'block' }}
                    />
                  ))}
                </div>
              )}
              <div ref={bottomRef} />
            </div>

            {/* Quick prompts */}
            <div style={{ padding: '0 16px', display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
              {QUICK_PROMPTS.map((p, i) => (
                <motion.button
                  key={i}
                  whileHover={{ scale: 1.04 }}
                  whileTap={{ scale: 0.97 }}
                  onClick={() => sendMessage(p)}
                  style={{
                    background: 'rgba(108,99,255,0.12)',
                    border: '1px solid rgba(108,99,255,0.3)',
                    borderRadius: '99px', color: 'rgba(255,255,255,0.8)',
                    cursor: 'pointer', fontSize: '0.68rem', padding: '4px 10px',
                    fontFamily: 'Inter', transition: 'all 0.2s',
                  }}
                >{p}</motion.button>
              ))}
            </div>

            {/* Input */}
            <div style={{ padding: '12px 16px', display: 'flex', gap: '8px' }}>
              <input
                id="aichat-input"
                className="glass-input"
                placeholder="Ask anything about your field data..."
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && sendMessage()}
                style={{ borderRadius: '10px', padding: '10px 14px', fontSize: '0.82rem' }}
              />
              <motion.button
                whileHover={{ scale: 1.08 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => sendMessage()}
                id="aichat-send"
                className="btn-glow"
                style={{ padding: '10px 14px', borderRadius: '10px', fontSize: '1rem', flexShrink: 0 }}
              >
                <span>➤</span>
              </motion.button>
            </div>
          </GlassCard>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
