from fastapi import APIRouter, HTTPException, Query
from database.supabase_client import supabase
from pydantic import BaseModel
from typing import Optional
from datetime import date

router = APIRouter()

class ReportCreate(BaseModel):
    tsm_id: str
    date: date
    outlets_visited: int
    orders_taken: int
    stockouts: int
    competitor_activity: Optional[str] = None
    notes: Optional[str] = None

@router.get("/")
async def get_reports(tsm_id: Optional[str] = Query(None), limit: int = 50):
    """Get TSM field reports."""
    query = supabase.table("tsm_reports").select("*, users(name, region)").order("date", desc=True).limit(limit)
    if tsm_id:
        query = query.eq("tsm_id", tsm_id)
    result = query.execute()
    return result.data

@router.get("/summary")
async def get_report_summary():
    """Get today's report submission summary."""
    from datetime import date as d
    today = d.today().isoformat()
    result = supabase.table("tsm_reports").select("*").eq("date", today).execute()
    return {"date": today, "count": len(result.data), "reports": result.data}

@router.post("/")
async def submit_report(report: ReportCreate):
    result = supabase.table("tsm_reports").insert(report.dict()).execute()
    return result.data
