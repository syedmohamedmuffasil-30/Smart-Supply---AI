from fastapi import APIRouter, HTTPException
from database.supabase_client import supabase
from pydantic import BaseModel
from typing import Optional
from datetime import datetime

router = APIRouter()

class UserCreate(BaseModel):
    name: str
    email: str
    role: str  # RSM / TSM / Admin
    region: Optional[str] = None
    phone: Optional[str] = None

@router.get("/")
async def get_users():
    """Get all users."""
    result = supabase.table("users").select("*").execute()
    return result.data

@router.get("/{user_id}")
async def get_user(user_id: str):
    """Get a single user by ID."""
    result = supabase.table("users").select("*").eq("id", user_id).single().execute()
    if not result.data:
        raise HTTPException(status_code=404, detail="User not found")
    return result.data

@router.post("/")
async def create_user(user: UserCreate):
    """Create a new user profile."""
    result = supabase.table("users").insert(user.dict()).execute()
    return result.data
