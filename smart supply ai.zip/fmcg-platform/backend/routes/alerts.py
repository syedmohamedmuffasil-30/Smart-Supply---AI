from fastapi import APIRouter, Query
from database.supabase_client import supabase
from pydantic import BaseModel
from typing import Optional

router = APIRouter()

class AlertCreate(BaseModel):
    area: str
    competitor_name: str
    offer_description: str
    threat_level: str  # 'low' | 'medium' | 'high'
    reported_by: str

@router.get("/")
async def get_alerts(threat_level: Optional[str] = Query(None), limit: int = 50):
    """Get competitor alerts, ordered by recency."""
    query = supabase.table("competitor_alerts").select("*").order("created_at", desc=True).limit(limit)
    if threat_level:
        query = query.eq("threat_level", threat_level)
    result = query.execute()
    return result.data

@router.get("/high-priority")
async def get_high_priority_alerts():
    """Get only HIGH threat level alerts."""
    result = supabase.table("competitor_alerts").select("*").eq("threat_level", "high").order("created_at", desc=True).execute()
    return result.data

@router.post("/")
async def create_alert(alert: AlertCreate):
    result = supabase.table("competitor_alerts").insert(alert.dict()).execute()
    return result.data
