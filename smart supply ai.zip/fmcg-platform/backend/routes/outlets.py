from fastapi import APIRouter, HTTPException, Query
from database.supabase_client import supabase
from pydantic import BaseModel
from typing import Optional

router = APIRouter()

class OutletCreate(BaseModel):
    name: str
    area: str
    district: str
    lat: float
    lng: float
    retailer_name: str
    phone: Optional[str] = None

@router.get("/")
async def get_outlets(district: Optional[str] = Query(None)):
    """Get all outlets, optionally filtered by district."""
    query = supabase.table("outlets").select("*")
    if district:
        query = query.eq("district", district)
    result = query.execute()
    return result.data

@router.get("/{outlet_id}")
async def get_outlet(outlet_id: str):
    """Get single outlet with latest stock levels."""
    outlet = supabase.table("outlets").select("*").eq("id", outlet_id).single().execute()
    if not outlet.data:
        raise HTTPException(status_code=404, detail="Outlet not found")
    stock = supabase.table("stock_levels").select("*").eq("outlet_id", outlet_id).execute()
    return {"outlet": outlet.data, "stock": stock.data}

@router.post("/")
async def create_outlet(outlet: OutletCreate):
    result = supabase.table("outlets").insert(outlet.dict()).execute()
    return result.data
