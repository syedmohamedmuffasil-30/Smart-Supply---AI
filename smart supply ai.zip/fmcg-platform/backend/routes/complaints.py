from fastapi import APIRouter, HTTPException, Query
from database.supabase_client import supabase
from pydantic import BaseModel
from typing import Optional
from datetime import datetime

router = APIRouter()

class ComplaintCreate(BaseModel):
    outlet_id: str
    product: str
    issue_type: str  # 'quality' | 'delivery' | 'pricing' | 'other'
    description: str
    assigned_to: Optional[str] = None

class ComplaintUpdate(BaseModel):
    status: str  # 'open' | 'in_progress' | 'resolved'
    assigned_to: Optional[str] = None

@router.get("/")
async def get_complaints(status: Optional[str] = Query(None)):
    """Get all complaints, optionally filtered by status."""
    query = supabase.table("complaints").select("*, outlets(name, area)").order("created_at", desc=True)
    if status:
        query = query.eq("status", status)
    result = query.execute()
    return result.data

@router.post("/")
async def create_complaint(complaint: ComplaintCreate):
    data = complaint.dict()
    data["status"] = "open"
    result = supabase.table("complaints").insert(data).execute()
    return result.data

@router.patch("/{complaint_id}")
async def update_complaint_status(complaint_id: str, update: ComplaintUpdate):
    data = update.dict(exclude_none=True)
    if update.status == "resolved":
        data["resolved_at"] = datetime.utcnow().isoformat()
    result = supabase.table("complaints").update(data).eq("id", complaint_id).execute()
    return result.data
