-- ============================================================
-- HATSUN AGRO FMCG SALES INTELLIGENCE PLATFORM
-- Database Schema + Seed Data
-- Run this in Supabase → SQL Editor
-- ============================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ──────────────────────────────────────────────────────────────
-- TABLE 1: users
-- ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.users (
    id          UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    name        TEXT NOT NULL,
    email       TEXT UNIQUE NOT NULL,
    role        TEXT NOT NULL CHECK (role IN ('RSM', 'TSM', 'Admin')),
    region      TEXT,
    phone       TEXT,
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ──────────────────────────────────────────────────────────────
-- TABLE 2: outlets
-- ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.outlets (
    id              UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    name            TEXT NOT NULL,
    area            TEXT NOT NULL,
    district        TEXT NOT NULL,
    lat             DECIMAL(10, 7) NOT NULL,
    lng             DECIMAL(10, 7) NOT NULL,
    retailer_name   TEXT NOT NULL,
    phone           TEXT,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ──────────────────────────────────────────────────────────────
-- TABLE 3: stock_levels
-- ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.stock_levels (
    id              UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    outlet_id       UUID REFERENCES public.outlets(id) ON DELETE CASCADE,
    product_name    TEXT NOT NULL,
    quantity        INTEGER NOT NULL DEFAULT 0,
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ──────────────────────────────────────────────────────────────
-- TABLE 4: tsm_reports
-- ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.tsm_reports (
    id                      UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    tsm_id                  UUID REFERENCES public.users(id) ON DELETE CASCADE,
    date                    DATE NOT NULL,
    outlets_visited         INTEGER NOT NULL DEFAULT 0,
    orders_taken            INTEGER NOT NULL DEFAULT 0,
    stockouts               INTEGER NOT NULL DEFAULT 0,
    competitor_activity     TEXT,
    notes                   TEXT,
    created_at              TIMESTAMPTZ DEFAULT NOW()
);

-- ──────────────────────────────────────────────────────────────
-- TABLE 5: complaints
-- ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.complaints (
    id              UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    outlet_id       UUID REFERENCES public.outlets(id) ON DELETE CASCADE,
    product         TEXT NOT NULL,
    issue_type      TEXT NOT NULL CHECK (issue_type IN ('quality', 'delivery', 'pricing', 'other')),
    description     TEXT,
    status          TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'in_progress', 'resolved')),
    assigned_to     UUID REFERENCES public.users(id),
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    resolved_at     TIMESTAMPTZ
);

-- ──────────────────────────────────────────────────────────────
-- TABLE 6: competitor_alerts
-- ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.competitor_alerts (
    id                  UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    area                TEXT NOT NULL,
    competitor_name     TEXT NOT NULL,
    offer_description   TEXT NOT NULL,
    threat_level        TEXT NOT NULL CHECK (threat_level IN ('low', 'medium', 'high')),
    reported_by         UUID REFERENCES public.users(id),
    created_at          TIMESTAMPTZ DEFAULT NOW()
);

-- ══════════════════════════════════════════════════════════════
-- SEED DATA
-- ══════════════════════════════════════════════════════════════

-- ── Users ─────────────────────────────────────────────────────
INSERT INTO public.users (id, name, email, role, region, phone) VALUES
  ('a1000000-0000-0000-0000-000000000001', 'Arjun Krishnamurthy', 'arjun@hatsun.com',  'Admin',  'HQ - Chennai',       '9876543210'),
  ('a1000000-0000-0000-0000-000000000002', 'Priya Sundaram',      'priya@hatsun.com',   'RSM',    'South Tamil Nadu',   '9876543211'),
  ('a1000000-0000-0000-0000-000000000003', 'Rajan Murugan',       'rajan@hatsun.com',   'TSM',    'Chennai South Zone', '9876543212'),
  ('a1000000-0000-0000-0000-000000000004', 'Deepa Venkatesh',     'deepa@hatsun.com',   'TSM',    'Chennai North Zone', '9876543213'),
  ('a1000000-0000-0000-0000-000000000005', 'Karthik Selvam',      'karthik@hatsun.com', 'RSM',    'North Tamil Nadu',   '9876543214'),
  ('a1000000-0000-0000-0000-000000000006', 'Meena Rajendran',     'meena@hatsun.com',   'TSM',    'Coimbatore Zone',    '9876543215'),
  ('a1000000-0000-0000-0000-000000000007', 'Suresh Balakumar',    'suresh@hatsun.com',  'TSM',    'Madurai Zone',       '9876543216')
ON CONFLICT (email) DO NOTHING;

-- ── Outlets ───────────────────────────────────────────────────
INSERT INTO public.outlets (id, name, area, district, lat, lng, retailer_name, phone) VALUES
  ('b1000000-0000-0000-0000-000000000001', 'Sri Murugan Stores',     'Velachery',     'Chennai',     13.0002,  80.2209,  'Murugan Annamalai',  '9944332211'),
  ('b1000000-0000-0000-0000-000000000002', 'Lakshmi Departmental',   'T.Nagar',       'Chennai',     13.0418,  80.2341,  'Lakshmi Venkat',     '9944332212'),
  ('b1000000-0000-0000-0000-000000000003', 'Cool Corner Shop',       'Adyar',         'Chennai',     13.0067,  80.2574,  'Suresh Kumar',       '9944332213'),
  ('b1000000-0000-0000-0000-000000000004', 'Star Provisions',        'Tambaram',      'Chennai',     12.9249,  80.1000,  'Ravi Chandran',      '9944332214'),
  ('b1000000-0000-0000-0000-000000000005', 'Fresh Dairy Point',      'Anna Nagar',    'Chennai',     13.0891,  80.2101,  'Anand Pillai',       '9944332215'),
  ('b1000000-0000-0000-0000-000000000006', 'Ganesh Superstore',      'RS Puram',      'Coimbatore',  11.0168,  76.9558,  'Ganesh Natarajan',   '9944332216'),
  ('b1000000-0000-0000-0000-000000000007', 'City Dairy Hub',         'Singanallur',   'Coimbatore',  10.9974,  77.0034,  'Prabhakaran R',      '9944332217'),
  ('b1000000-0000-0000-0000-000000000008', 'Madurai Milk Centre',    'Anna Nagar',    'Madurai',     9.9312,   78.1188,  'Muthu Pandian',      '9944332218'),
  ('b1000000-0000-0000-0000-000000000009', 'South Star Provisions',  'KK Nagar',      'Madurai',     9.9252,   78.0998,  'Selvam R',           '9944332219'),
  ('b1000000-0000-0000-0000-000000000010', 'Salem Dairy Depot',      'Fairlands',     'Salem',       11.6643,  78.1460,  'Balasubramaniam',    '9944332220')
ON CONFLICT DO NOTHING;

-- ── Stock Levels ──────────────────────────────────────────────
INSERT INTO public.stock_levels (outlet_id, product_name, quantity, updated_at) VALUES
  -- Velachery
  ('b1000000-0000-0000-0000-000000000001', 'Hatsun Curd 500g',       45,  NOW() - INTERVAL '2 hours'),
  ('b1000000-0000-0000-0000-000000000001', 'Hatsun Curd 1L',         30,  NOW() - INTERVAL '2 hours'),
  ('b1000000-0000-0000-0000-000000000001', 'Arun Ice Cream 500ml',    0,  NOW() - INTERVAL '3 hours'),  -- STOCKOUT
  ('b1000000-0000-0000-0000-000000000001', 'Ibaco Premium 1L',       12,  NOW() - INTERVAL '2 hours'),
  -- T.Nagar
  ('b1000000-0000-0000-0000-000000000002', 'Hatsun Milk 1L',        120,  NOW() - INTERVAL '1 hour'),
  ('b1000000-0000-0000-0000-000000000002', 'Hatsun Curd 500g',        0,  NOW() - INTERVAL '4 hours'),  -- STOCKOUT
  ('b1000000-0000-0000-0000-000000000002', 'Hatsun Paneer 200g',     25,  NOW() - INTERVAL '1 hour'),
  ('b1000000-0000-0000-0000-000000000002', 'Ibaco Vanilla 500ml',    18,  NOW() - INTERVAL '1 hour'),
  -- Adyar
  ('b1000000-0000-0000-0000-000000000003', 'Hatsun Curd 1L',          0,  NOW() - INTERVAL '6 hours'),  -- STOCKOUT
  ('b1000000-0000-0000-0000-000000000003', 'Hatsun Milk 500ml',      80,  NOW() - INTERVAL '1 hour'),
  ('b1000000-0000-0000-0000-000000000003', 'Arun Choco Bar',         40,  NOW() - INTERVAL '1 hour'),
  -- Anna Nagar
  ('b1000000-0000-0000-0000-000000000005', 'Hatsun Milk 1L',        200,  NOW()),
  ('b1000000-0000-0000-0000-000000000005', 'Hatsun Curd 500g',       60,  NOW()),
  ('b1000000-0000-0000-0000-000000000005', 'Ibaco Premium 1L',       35,  NOW()),
  -- Coimbatore RS Puram
  ('b1000000-0000-0000-0000-000000000006', 'Hatsun Milk 1L',         90,  NOW() - INTERVAL '30 min'),
  ('b1000000-0000-0000-0000-000000000006', 'Hatsun Curd 1L',         45,  NOW() - INTERVAL '30 min'),
  ('b1000000-0000-0000-0000-000000000006', 'Arun Ice Cream 500ml',   22,  NOW() - INTERVAL '30 min');

-- ── TSM Reports ───────────────────────────────────────────────
INSERT INTO public.tsm_reports (tsm_id, date, outlets_visited, orders_taken, stockouts, competitor_activity, notes) VALUES
  ('a1000000-0000-0000-0000-000000000003', CURRENT_DATE,              12, 9, 2, 'Amul discount at Velachery', 'Two outlets requested faster delivery on curd.'),
  ('a1000000-0000-0000-0000-000000000004', CURRENT_DATE,              10, 8, 1, 'None observed',              'Anna Nagar cluster performing well. New outlet onboarded.'),
  ('a1000000-0000-0000-0000-000000000003', CURRENT_DATE - 1,          14, 12, 0, 'Dodla promo in Tambaram',   'Good day, all orders fulfilled on time.'),
  ('a1000000-0000-0000-0000-000000000004', CURRENT_DATE - 1,          11, 9, 1, 'Mother Dairy price cut',    'Cold chain delay at Adyar outlet — escalated to logistics.'),
  ('a1000000-0000-0000-0000-000000000006', CURRENT_DATE,              8,  6, 0, 'Heritage BTL activity',     'Coimbatore RS Puram — strong footfall. Demand up 20%.'),
  ('a1000000-0000-0000-0000-000000000007', CURRENT_DATE,              7,  5, 2, 'Aavin price drop scheme',   'Madurai outlets requesting more frozen products. Two stockouts noted.'),
  ('a1000000-0000-0000-0000-000000000003', CURRENT_DATE - 2,          13, 11, 0, 'None observed',            'All outlets compliant. Planogram updated in 3 stores.');

-- ── Complaints ────────────────────────────────────────────────
INSERT INTO public.complaints (outlet_id, product, issue_type, description, status, assigned_to) VALUES
  ('b1000000-0000-0000-0000-000000000001', 'Hatsun Curd 500g',    'quality',  'Customer reported sour taste before expiry date.',  'open',        'a1000000-0000-0000-0000-000000000003'),
  ('b1000000-0000-0000-0000-000000000002', 'Hatsun Milk 1L',      'delivery', '3-day supply gap caused stockout during weekend.',   'in_progress', 'a1000000-0000-0000-0000-000000000004'),
  ('b1000000-0000-0000-0000-000000000003', 'Ibaco Premium 1L',    'pricing',  'Retailer overcharging above MRP by ₹10.',            'open',        'a1000000-0000-0000-0000-000000000003'),
  ('b1000000-0000-0000-0000-000000000004', 'Arun Ice Cream 500ml','quality',  'Partial melting due to freezer issue during transit.','in_progress', 'a1000000-0000-0000-0000-000000000004'),
  ('b1000000-0000-0000-0000-000000000005', 'Hatsun Paneer 200g',  'delivery', 'Order placed 5 days ago, not delivered yet.',         'open',        'a1000000-0000-0000-0000-000000000003'),
  ('b1000000-0000-0000-0000-000000000006', 'Hatsun Curd 1L',      'quality',  'Packaging torn on 4 units in last delivery batch.',  'resolved',    'a1000000-0000-0000-0000-000000000006'),
  ('b1000000-0000-0000-0000-000000000008', 'Hatsun Milk 500ml',   'other',    'Wrong SKU delivered — 500ml instead of 1L.',         'open',        'a1000000-0000-0000-0000-000000000007');

-- Update resolved complaint
UPDATE public.complaints
SET resolved_at = NOW() - INTERVAL '2 hours'
WHERE outlet_id = 'b1000000-0000-0000-0000-000000000006' AND status = 'resolved';

-- ── Competitor Alerts ─────────────────────────────────────────
INSERT INTO public.competitor_alerts (area, competitor_name, offer_description, threat_level, reported_by) VALUES
  ('Velachery, Chennai',      'Amul',         '₹5 discount on Amul Butter 500g — running for 2 weeks in key outlets.',           'high',   'a1000000-0000-0000-0000-000000000003'),
  ('Tambaram, Chennai',       'Dodla Dairy',  'Buy 2 Get 1 Free on Dodla Fresh Curd 1L — aggressive campaign.',                  'high',   'a1000000-0000-0000-0000-000000000003'),
  ('RS Puram, Coimbatore',    'Heritage',     'Heritage below-the-line activity: shelf displays + price cards at 12 outlets.',    'medium', 'a1000000-0000-0000-0000-000000000006'),
  ('Singanallur, Coimbatore', 'Mother Dairy', 'Mother Dairy ₹2 MRP reduction on 1L Toned Milk effective this week.',             'medium', 'a1000000-0000-0000-0000-000000000006'),
  ('Anna Nagar, Madurai',     'Aavin',        'Aavin state scheme: 10% subsidy on milk for government ration card holders.',      'medium', 'a1000000-0000-0000-0000-000000000007'),
  ('KK Nagar, Madurai',       'Milma',        'Milma entering Tamil Nadu market with introductory pricing at ₹50/L.',            'low',    'a1000000-0000-0000-0000-000000000007'),
  ('T.Nagar, Chennai',        'Nandini',      'Nandini Ghee sampling activity at supermarkets — Karnataka brand expansion.',      'low',    'a1000000-0000-0000-0000-000000000004'),
  ('Fairlands, Salem',        'Amul',         'Amul Ice Cream push before summer — refrigerator placement sponsorship offer.',    'high',   'a1000000-0000-0000-0000-000000000005');

-- ══════════════════════════════════════════════════════════════
-- ROW LEVEL SECURITY (optional — enable for production)
-- ══════════════════════════════════════════════════════════════

-- ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE public.outlets ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE public.stock_levels ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE public.tsm_reports ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE public.complaints ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE public.competitor_alerts ENABLE ROW LEVEL SECURITY;
