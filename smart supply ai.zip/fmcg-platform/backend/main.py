from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import uvicorn

from routes import outlets, reports, complaints, alerts, users

@asynccontextmanager
async def lifespan(app: FastAPI):
    print("🚀 Hatsun Agro FMCG Platform API starting...")
    yield
    print("✅ API shutdown complete.")

app = FastAPI(
    title="Hatsun Agro FMCG Sales Intelligence API",
    description="Backend API for the FMCG Sales Intelligence Platform powering Hatsun Agro's field operations.",
    version="1.0.0",
    lifespan=lifespan,
)

# ─── CORS ──────────────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─── Routers ───────────────────────────────────────────────────────
app.include_router(users.router,      prefix="/users",      tags=["Users"])
app.include_router(outlets.router,    prefix="/outlets",    tags=["Outlets"])
app.include_router(reports.router,    prefix="/reports",    tags=["TSM Reports"])
app.include_router(complaints.router, prefix="/complaints", tags=["Complaints"])
app.include_router(alerts.router,     prefix="/alerts",     tags=["Competitor Alerts"])

# ─── Health ────────────────────────────────────────────────────────
@app.get("/", tags=["Health"])
async def root():
    return {
        "status": "✅ Hatsun Agro API is live",
        "version": "1.0.0",
        "docs": "/docs",
    }

@app.get("/health", tags=["Health"])
async def health():
    return {"status": "healthy", "service": "fmcg-platform"}

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
